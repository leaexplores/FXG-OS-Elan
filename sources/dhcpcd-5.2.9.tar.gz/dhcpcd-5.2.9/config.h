/* linux */
#define SYSCONFDIR	"/usr/local/etc"
#define SBINDIR		"/usr/local/sbin"
#define LIBEXECDIR	"/usr/local/libexec"
#define DBDIR		"/var/db"
#define RUNDIR		"/var/run"
#include "compat/arc4random.h"
#include "compat/closefrom.h"
#include "compat/strlcpy.h"
